## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/d3-js-complete-developer-data-visualization-guide-video/9781800565692)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# D3.js-Complete-Developer-Data-Visualization-Guide
D3.js: Complete Developer Data Visualization Guide by Packt Publishing
